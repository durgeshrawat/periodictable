from tkinter import *
from KEEpydb import KEEpydb
import random
class main:
	def __init__(self,display):
		self.db=KEEpydb.query('db','dbmain','')
		self.display=display
		self.appwidth=700
		self.appheight=1000
		self.qus=self.db.get_all()
		self.index=2
		self.home()
		
	def home(self):
		f=Frame(self.display).place(x=0,y=0,width=self.appwidth,height=self.appheight)
		Button(f,text='Start Chem Quiz',command=self.startchemquiz).place(x=50,y=200,width=500)
		Button(f,text='Settings',command=self.settings).place(x=50,y=300,width=500)
	
	def startchemquiz(self):
		self.chem_()
	
	def chem_(self):
		f=Frame(self.display).place(x=0,y=0,width=self.appwidth,height=self.appheight)
		question=Label(f,text='')
		question.pack()
		ques=self.qus[self.index]
		question.config(text=ques[0])
		self.index+=1
		option_random=[1,2,3,4]
		random.shuffle(option_random)					
		Button(f,text=ques[option_random[0]]).pack()
		Button(f,text=ques[option_random[1]]).pack()
		Button(f,text=ques[option_random[2]]).pack()
		Button(f,text=ques[option_random[3]]).pack()
		
		
	def settings(self):
		pass

root=Tk()
m=main(root)
root.mainloop()		